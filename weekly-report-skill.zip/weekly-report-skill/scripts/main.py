#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import sys
import re
from datetime import datetime, timedelta

# 导入阿里云百炼
import dashscope
from dashscope import Generation

# 设置 API-KEY（已填入你的 KEY）
dashscope.api_key = "sk-01a6403f616649a896b89d20b782d02b"

def extract_index_data(text):
    """提取指数涨跌幅及相对收益"""
    index_match = re.search(r'建筑装饰[（(]申万[）)]指数[上涨下跌]([\d\.]+)%', text)
    index_change = index_match.group(1) if index_match else "N/A"
    
    sh_match = re.search(r'相对上证指数[跑赢跑输]([\d\.]+)pct', text)
    sh_diff = f"+{sh_match.group(1)}" if sh_match and '跑赢' in text else f"-{sh_match.group(1)}" if sh_match else "N/A"
    
    hs300_match = re.search(r'相对沪深300[跑赢跑输]([\d\.]+)pct', text)
    hs300_diff = f"+{hs300_match.group(1)}" if hs300_match and '跑赢' in text else f"-{hs300_match.group(1)}" if hs300_match else "N/A"
    
    return {
        "index_change": index_change,
        "sh_diff": sh_diff,
        "hs300_diff": hs300_diff
    }

def extract_top_stocks(text):
    """提取个股涨跌幅前五"""
    gainers_pattern = r'周涨幅居前五[：:；](.+?)(?:周跌幅|跌幅前五|$)'
    gainers_match = re.search(gainers_pattern, text, re.DOTALL)
    gainers = []
    if gainers_match:
        gainers_text = gainers_match.group(1)
        gainers = re.findall(r'([\u4e00-\u9fa5]+)[（(]([+\-\d\.]+)%[）)]', gainers_text)
    
    losers_pattern = r'周跌幅居前五[：:；](.+?)(?:二、|$)'
    losers_match = re.search(losers_pattern, text, re.DOTALL)
    losers = []
    if losers_match:
        losers_text = losers_match.group(1)
        losers = re.findall(r'([\u4e00-\u9fa5]+)[（(]([+\-\d\.]+)%[）)]', losers_text)
    
    return {
        "gainers": gainers[:5],
        "losers": losers[:5]
    }

def extract_bond_data(text):
    """提取专项债数据"""
    weekly_match = re.search(r'本周专项债新增发行(\d+)亿元', text)
    weekly = weekly_match.group(1) if weekly_match else "N/A"
    
    total_match = re.search(r'年初以来累计发行(\d+)亿元', text)
    total = total_match.group(1) if total_match else "N/A"
    
    yoy_match = re.search(r'同比发行多(\d+)亿元', text)
    yoy = yoy_match.group(1) if yoy_match else "N/A"
    
    progress_match = re.search(r'累计发行进度(\d+)%(?:，|,)?同比快([\d\.]+)pct', text)
    progress = progress_match.group(1) if progress_match else "N/A"
    progress_diff = progress_match.group(2) if progress_match else "N/A"
    
    return {
        "weekly": weekly,
        "total": total,
        "yoy": yoy,
        "progress": progress,
        "progress_diff": progress_diff
    }

def extract_funding_data(text):
    """提取资金到位率数据"""
    overall_match = re.search(r'资金到位率为([\d\.]+)%', text)
    overall = overall_match.group(1) if overall_match else "N/A"
    
    mom_match = re.search(r'周环比[升降]([\d\.]+)个百分点', text)
    mom = mom_match.group(1) if mom_match else "N/A"
    mom_direction = "升" if "升" in text and mom_match else "降" if mom_match else ""
    
    non_housing_match = re.search(r'非房建项目资金到位率为([\d\.]+)%', text)
    non_housing = non_housing_match.group(1) if non_housing_match else "N/A"
    
    housing_match = re.search(r'房建项目资金到位率为([\d\.]+)%', text)
    housing = housing_match.group(1) if housing_match else "N/A"
    
    return {
        "overall": overall,
        "mom": mom,
        "mom_direction": mom_direction,
        "non_housing": non_housing,
        "housing": housing
    }

def extract_recommendations(text):
    """提取推荐标的和逻辑"""
    rec_match = re.search(r'推荐标的[：:](.+?)(?:\n|$)', text)
    if rec_match:
        rec_text = rec_match.group(1)
        companies = re.findall(r'[\u4e00-\u9fa5]{2,6}(?:股份|集团|科技|建设|国际|工程)*', rec_text)
        companies = list(set(companies))[:5]
    else:
        companies = []
    
    sections = {}
    patterns = [
        (r'煤化工[----]+(.+?)(?=电力建设|绿色能源|$)', "煤化工"),
        (r'电力建设[----]+(.+?)(?=绿色能源|$)', "电力建设"),
        (r'绿色能源[----]+(.+?)(?=$)', "绿色能源")
    ]
    
    for pattern, key in patterns:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            logic = match.group(1).replace('\n', '').strip()[:100]
            sections[key] = logic
    
    return {
        "companies": companies,
        "logics": sections
    }

def generate_report_with_ai(text):
    """使用 Qwen AI 生成报告"""
    # 先提取结构化数据
    index_data = extract_index_data(text)
    stocks = extract_top_stocks(text)
    bond = extract_bond_data(text)
    funding = extract_funding_data(text)
    rec = extract_recommendations(text)
    
    # 构建提示词
    today = datetime.now()
    last_monday = today - timedelta(days=today.weekday() + 7)
    last_sunday = last_monday + timedelta(days=6)
    date_range = f"{last_monday.strftime('%Y年%m月%d日')}-{last_sunday.strftime('%Y年%m月%d日')}"
    
    # 构建 AI 提示词
    prompt = f"""你是一位专业的建筑行业研究员，请根据以下数据生成一份专业的建筑行业周报。

【数据时间】：{date_range}

【板块表现】：
- 建筑装饰（申万）指数：上涨{index_data['index_change']}%
- 相对上证指数：{index_data['sh_diff']}pct
- 相对沪深300：{index_data['hs300_diff']}pct

【个股表现】：
- 涨幅前五：{', '.join([f'{name}（{change}%)' for name, change in stocks['gainers']]) if stocks['gainers'] else 'N/A'}
- 跌幅前五：{', '.join([f'{name}（{change}%)' for name, change in stocks['losers']]) if stocks['losers'] else 'N/A'}

【专项债数据】：
- 本周新增发行：{bond['weekly']}亿元
- 年初累计发行：{bond['total']}亿元
- 同比多增：{bond['yoy']}亿元
- 发行进度：{bond['progress']}%，同比快{bond['progress_diff']}pct

【资金到位率】：
- 整体：{funding['overall']}%，周环比{funding['mom_direction']}{funding['mom']}pct
- 非房建项目：{funding['non_housing']}%
- 房建项目：{funding['housing']}%

【推荐标的】：{'、'.join(rec['companies']) if rec['companies'] else '详见正文'}

【行业逻辑要点】：
{chr(10).join([f'- {k}：{v}' for k, v in rec['logics'].items()]) if rec['logics'] else '- 煤化工、电力建设、绿色能源等方向'}

请生成一份专业的建筑行业周报，包含：
1. 本周板块及个股数据回顾
2. 行业重点数据更新（专项债、资金到位率）
3. 研究员观点（推荐标的和行业逻辑）

要求：专业、简洁、逻辑清晰，适合机构投资者阅读。"""

    # 调用 Qwen 生成报告
    print("正在使用 Qwen 生成报告...")
    response = Generation.call(
        model="qwen-plus",
        messages=[
            {"role": "system", "content": "你是一位专业的建筑行业研究员，擅长撰写行业周报。"},
            {"role": "user", "content": prompt}
        ]
    )
    
    if response.status_code == 200:
        return response.output.text
    else:
        print(f"AI 生成失败，使用模板生成。错误：{response.message}")
        return generate_report_template(text)

def generate_report_template(text):
    """原始模板生成方式（备用）"""
    index_data = extract_index_data(text)
    stocks = extract_top_stocks(text)
    bond = extract_bond_data(text)
    funding = extract_funding_data(text)
    rec = extract_recommendations(text)
    
    today = datetime.now()
    last_monday = today - timedelta(days=today.weekday() + 7)
    last_sunday = last_monday + timedelta(days=6)
    date_range = f"{last_monday.strftime('%Y年%m月%d日')}-{last_sunday.strftime('%Y年%m月%d日')}"
    
    report = f"""**一、本周板块及个股数据回顾**

(1)本周（{date_range})建筑装饰（申万）指数上涨{index_data['index_change']}%，相对上证指数{index_data['sh_diff']}pct，相对沪深300{index_data['hs300_diff']}pct。本周建筑个股中"""
    
    if stocks['gainers']:
        gainers_str = "、".join([f"{name}（{change}%）" for name, change in stocks['gainers']])
        report += gainers_str + "周涨幅居前五"
    
    if stocks['losers']:
        losers_str = "、".join([f"{name}（{change}%）" for name, change in stocks['losers']])
        report += f"；{losers_str}周跌幅居前五"
    
    report += f"""

**二、行业重点数据更新**

（一）专项债周度数据更新

本周专项债新增发行{bond['weekly']}亿元，年初以来累计发行{bond['total']}亿元，同比发行多{bond['yoy']}亿元，累计发行进度{bond['progress']}%，同比快{bond['progress_diff']}pct。

据百年建筑调研，截至 {today.strftime('%m月%d日')}，样本建筑工地资金到位率为{funding['overall']}%，周环比{funding['mom_direction']} {funding['mom']} 个百分点。
其中，非房建项目资金到位率为 {funding['non_housing']}%，房建项目资金到位率为 {funding['housing']}%。

**三、研究员观点：**

推荐标的：{'、'.join(rec['companies']) if rec['companies'] else '详见正文'}

行业和重点公司更新：

"""
    
    if "煤化工" in rec['logics']:
        report += f"""煤化工------{rec['logics']['煤化工']}...

"""
    if "电力建设" in rec['logics']:
        report += f"""电力建设------{rec['logics']['电力建设']}...

"""
    if "绿色能源" in rec['logics']:
        report += f"""绿色能源------{rec['logics']['绿色能源']}...

"""
    
    report += f"""
此外，欧洲能源价格上行预期下，关注北方国际克罗地亚风电项目的业绩弹性。

---
*报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}*"""
    
    return report

def main():
    if len(sys.argv) > 1:
        user_input = sys.argv[1]
    else:
        # 测试数据
        user_input = """本周建筑装饰（申万）指数上涨4.12%，相对上证指数跑赢4.85pct，相对沪深300跑赢3.93pct。
        本周建筑个股中中国能建（+29.4%）、宁波建工（+23.7%）、中国电建（+20.6%）、国晟科技（+19.8%）、中国核建（+16.0%）周涨幅居前五；
        航天工程（-12.8%）、宏信建发（-9.7%）、宏润建设（-7.9%）、风语筑（-7.7%）、中天精装（-7.7%）周跌幅居前五。
        专项债本周新增发行177亿元，年初以来累计发行9201亿元，同比发行多2591亿元，累计发行进度21%，同比快5.9pct。
        资金到位率为57.53%，周环比升0.31个百分点，非房建项目资金到位率为59.59%，房建项目资金到位率为47.43%。
        推荐标的：中国化学、中国能建、中国电建。
        煤化工逻辑：国际油价上行带动煤化工经济性进一步凸显。电力建设逻辑：新财政形式下，电力投资高景气，接过稳增长大旗。
        绿色能源逻辑：两会提出设立国家低碳转型基金，培育氢能、绿色燃料等新增长点。"""
    
    # 使用 AI 生成报告
    report = generate_report_with_ai(user_input)
    
    # 保存到文件
    output_dir = "./outputs"
    import os
    os.makedirs(output_dir, exist_ok=True)
    
    output_file = f"{output_dir}/建筑行业周报_{datetime.now().strftime('%Y%m%d')}.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    # 输出结果
    result = {
        "success": True,
        "output_file": output_file,
        "content": report[:500] + "..." if len(report) > 500 else report,
        "ai_generated": True
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
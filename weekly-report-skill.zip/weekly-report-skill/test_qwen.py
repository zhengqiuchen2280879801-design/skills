﻿import dashscope
from dashscope import Generation

# 直接设置 API-KEY
dashscope.api_key = "sk-01a6403f616649a896b89d20b782d02b"

response = Generation.call(
    model="qwen-plus",
    messages=[{"role": "user", "content": "你好，请介绍一下自己"}]
)

print(response.output.text)